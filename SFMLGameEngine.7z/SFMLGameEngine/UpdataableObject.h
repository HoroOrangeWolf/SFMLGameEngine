#pragma once
class UpdataableObject
{
public:
	virtual void update() = 0;
};

