#pragma once
#include <SFML/Graphics.hpp>
class BitmapObject
{
protected:
	sf::Texture currentTexture;
	sf::Sprite currentSprite;

};

