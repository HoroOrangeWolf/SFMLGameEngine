#pragma once
#include "BitmapObject.h"
#include "AnimatedObject.h"

class SpriteObject: public BitmapObject, public AnimatedObject 
{

};

